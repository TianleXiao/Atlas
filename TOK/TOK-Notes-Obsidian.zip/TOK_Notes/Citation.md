# 引用

[[Academic-Integrity|学术诚信]] 中提到的要点之一。
