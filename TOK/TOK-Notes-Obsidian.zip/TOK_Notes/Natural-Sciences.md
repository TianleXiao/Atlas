# 自然科学

TOK 中的一个 [[AOK|AOK 知识领域]]。

可用 [[Knowledge-Framework|知识框架]]（范围、视角、方法与工具、伦理）来分析这一学科的知识本质。
